from typing import Union

from fastapi import FastAPI, HTTPException

app = FastAPI()


@app.get("/")
def read_root():
    return {"Hello": "World"}


@app.get("/rows/{row_index}")
def read_item(row_index: int):
    if row_index < 0 or row_index >= 500:
        raise HTTPException(status_code=404, detail="Item not found")
    with open("./data.bin", "rb") as f:
        f.seek(row_index*500)
        columns = [int.from_bytes(f.read(1), 'little') for _ in range(500)]
        return {"row_id": row_index, "columns": columns}
